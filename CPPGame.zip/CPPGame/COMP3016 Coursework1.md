# COMP3016 Coursework1

## System Version
Visual Studio Version: Visual Studio 2022(17.7.4)<br/>
Operating System Version: Windows11 Home Edition 22H2

## Description
The game code implements a simple role-playing game. The process of the game is that the player first chooses a character, and different characters have different ability values. After selecting the character, the player chooses the place to go, but my ability is limited, I only made one place, and that is HELL. Then we will have three monsters as our enemies to choose from, the enemies are random, there will be different enemies according to the level, all the enemies have different ability values. After selecting the enemy, the battle begins, the player has three options, attack, magic attack and return blood, and the success rate of each option is also displayed. In combat, both the player and the enemy have a chance of missing an attack. If the player wins the battle, the player receives experience points, which can be reached to upgrade an ability, such as attack or Magic attack. Then The game goes back to where the map was selected, and the game continues until the player reaches level 5 and challenges the final boss, The God. Beat him. Game over. If the player loses the battle, the character dies and the game ends. There is a small egg in the game, if you enter 666 in the character selection screen, the player can use the hidden character, Satan. His abilities are terrifying.

## Detail

Think about what kind of game it is, then define the variables. Use loop statements to do most of the work. Here are some examples.

switch (random3) { case 1: if (level <= 1) { cout << "(" << d + 2 << ")\n***************\nThe Tree(lvl 1):\n attack - 0\n defense - 20\n speed - 0\n***************\n"; cout << endl; } break; // ... other cases } So, the expression (level * -1) effectively negates the value of level. If level is, for example, 3, then d would be set to -3. This negated value is used in some switch-case statements to determine which opponents can be faced based on the level. d + 2 is used to present the opponent's level based on the player's level. If level is 3, d would be -3, and d + 2 would be -1. This is used to present the opponent level as -1 (opponent level 1).

The above code is for randomly generating enemies.

## Exception handling and test cases

We first tested whether we could select 6 characters and one hidden character. Test to see if you can access a unique location. To test whether enemies are randomly generated, there are three options. Test if our three options: Attack, Magic Attack and Recharge are normal. Test if the player is knocked down and the game ends. Test the ability to level up normally and whether the upgrade points can be added to the player's ability value. Test to see if the game ends properly after defeating the final boss.

## UML Design Diagram

use case diagram: <br/><img src=".\UMLclass_diagram.png"><br/>
class diagram: <br/>
<img src=".\UMLsequence _chart.png"><br/>
Sequence chart: <br/>
<img src=".\UMLusecase_diagram.png">

## Video Link：https://youtu.be/bTvBxeUrLAo

## Git Link：https://github.com/JiyefuChen/CW1/tree/master